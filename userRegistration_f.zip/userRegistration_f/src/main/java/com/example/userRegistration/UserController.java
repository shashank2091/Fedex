package com.example.userRegistration;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.client.RestTemplate;

@Controller
public class UserController {

	private UserRepository userRepo;
	
	@GetMapping("")
	public String viewHomePage() {
		return "index";
	}
	
	@GetMapping("/register")
	public String showRegistrationForm(Model model) {
		model.addAttribute("user", new User());
		
		return "signup_form";
	}
	
	@SuppressWarnings({ "restriction", "restriction" })
	@PostMapping("/process_register")
	public String processRegister(User user) throws URISyntaxException {
		
		//	For security
	
		/*BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		String encodedPassword = passwordEncoder.encode(user.getPassword());
		user.setPassword(encodedPassword);
		
		userRepo.save(user);*/
		
		
		//for sending request to the POST URL
		/*MultiValueMap<String, String> headers = new LinkedMultiValueMap<String, String>();
		headers.add("HeaderName", "value");
		headers.add("Content-Type", "application/json");
		
		RestTemplate restTemplate = new RestTemplate();
		
		
	     
	    final String baseUrl = "https://demo-api.now.sh/users";
	    URI uri = new URI(baseUrl);
	    
	     
	    User userDetails = new User();
	    userDetails.setFirstName(user.getFirstName());
	    userDetails.setLastName(user.getLastName());
	    userDetails.setEmail(user.getEmail());
	 
	    ResponseEntity<String> result = restTemplate.postForEntity(uri, userDetails, String.class);
	    jdk.internal.jline.internal.Log.info("result" + result);*/
		
		return "register_success";
	}
	
	@GetMapping("/users")
	public String listUsers(Model model) {
		List<User> listUsers = userRepo.findAll();
		model.addAttribute("listUsers", listUsers);
		
		return "users";
	}
}
